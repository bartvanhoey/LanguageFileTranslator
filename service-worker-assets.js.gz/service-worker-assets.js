self.assetsManifest = {
  "version": "VJwoaSHQ",
  "assets": [
    {
      "hash": "sha256-dzEMkwFpGWZbi+K96tEmSXIUnYWJw/+ia5cHnkANoOw=",
      "url": "JsonTranslatorApp.styles.css"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-K2Wvsx9NvmtkU4V07OCHCR0wmY6uNAnSuHp+KN2yAwc=",
      "url": "_framework/JetBrains.Annotations.75veoqxomf.wasm"
    },
    {
      "hash": "sha256-Iboriv0Twb+3CuKLXdI1x2sH0EKKmzypgjzGb+B0sNw=",
      "url": "_framework/JsonTranslatorApp.jjqij3tdy8.wasm"
    },
    {
      "hash": "sha256-e6NYhsj8eyJ1xkOGNY+n8smq4qdDYzh6A1KGIaH57X4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jim68xox88.wasm"
    },
    {
      "hash": "sha256-wqN95Lh/pnVkqk+dI3ZqbE5P7IdTODTrkrYVdMm5ViI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.upqayvcoqo.wasm"
    },
    {
      "hash": "sha256-p1qYWrnyVf4rMjY70Ar5jB8BAcQsVQ4SwECbJzrVjFw=",
      "url": "_framework/Microsoft.AspNetCore.Components.rz6lwpu5gc.wasm"
    },
    {
      "hash": "sha256-tkqSXRzZPeNbxtJ+IaZQez5Sw1oYvnS1QEhL3d5WvMQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.68pc0kvab2.wasm"
    },
    {
      "hash": "sha256-P7JqI4xNIvLXRyszZZ+sgn49azkqo9B1U0UYy5OyYs4=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.9egjw13m6v.wasm"
    },
    {
      "hash": "sha256-3D9JIcKCrX/w6+4jFQ8q9N/67OPnjpLLNIEFN22xVSY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wp0mzg5a2w.wasm"
    },
    {
      "hash": "sha256-ykA0KZ0JrE4ZtKEg8fgvq/wsCuLKkZmwiVwgA3Ydt6c=",
      "url": "_framework/Microsoft.Extensions.Configuration.q0vfeqgy49.wasm"
    },
    {
      "hash": "sha256-xUfV/BvVCp4B9E+6AQxK2VTdYg3FBUkzgKzgrMq4N9U=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.hl89w5mwa6.wasm"
    },
    {
      "hash": "sha256-Fx8PCZC8Hf7hAImnq6oOpMXcz/p4nQ1AyyS8feAn3BU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.p0lak51igt.wasm"
    },
    {
      "hash": "sha256-XkiN+nwEj7Xe6j7gsH0Q4mHyupK6VJuvC7tRKSv2xBk=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.ik8tjtuunz.wasm"
    },
    {
      "hash": "sha256-uAZVYqVtDXOclUTIFSV8ibAkoaOOI/qUnJmhQXg8ppw=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.0mjc3e3c8g.wasm"
    },
    {
      "hash": "sha256-C2KktPfzpXATvVvmrPF83kGB5goRQ5qiW6huOCvg1Zg=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.r42d299edj.wasm"
    },
    {
      "hash": "sha256-36782JGnyrv2+Yshj8UhZB8OxEAoqHEOqB+KxNoNvnI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pu91p8h6ns.wasm"
    },
    {
      "hash": "sha256-YIuzDGZI83GlNESnYTyMbdqJLsSTloCYq5EUscVTcx4=",
      "url": "_framework/Microsoft.Extensions.Logging.knt2que0yn.wasm"
    },
    {
      "hash": "sha256-aXfYBfRdGv8Z1PBN/5+izXYTKgcXhu8iQhl647u56lw=",
      "url": "_framework/Microsoft.Extensions.Options.5lr3lli8bg.wasm"
    },
    {
      "hash": "sha256-AjsTRohUMSrR9ZfCOi79wRFoVpo/VcKSXP1ZOcQCFUU=",
      "url": "_framework/Microsoft.Extensions.Primitives.62v70z4iar.wasm"
    },
    {
      "hash": "sha256-7WtjYQMbGWwUn9g+l5J/EwBeIysEUj1NQmwD/6JVHi8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lqrqdcga09.wasm"
    },
    {
      "hash": "sha256-d+WqurQW/ue57ffE7+JqV04RMIdksBUD4YmHWaX9FYc=",
      "url": "_framework/Microsoft.JSInterop.lh96pnvlhf.wasm"
    },
    {
      "hash": "sha256-dP6UAOHSUfIYdP90eumf5pB3JiO4+P2+WB5ZdzosTy8=",
      "url": "_framework/System.Collections.Concurrent.4kiq2f4od4.wasm"
    },
    {
      "hash": "sha256-plbkhfhFs7lulRXf4odOHnsVGCdUtprpKyZbGB+xrnQ=",
      "url": "_framework/System.Collections.Immutable.uikvhvhxyq.wasm"
    },
    {
      "hash": "sha256-N2XTeDs2hFGXwhswzoI+l9IBhdSpb/m8wxSoeftvd7A=",
      "url": "_framework/System.Collections.ltiekwvlfc.wasm"
    },
    {
      "hash": "sha256-l5HTmMtsqpripuHeUUxGGrivOO8V0iZiKDfJy+dUyu4=",
      "url": "_framework/System.ComponentModel.514k9tivag.wasm"
    },
    {
      "hash": "sha256-j39tSQgs//AMwt/nusYh0Cm+hG/RGpcXJ6Wc0YIoitE=",
      "url": "_framework/System.ComponentModel.Primitives.3vj4qunhgd.wasm"
    },
    {
      "hash": "sha256-fZtL5iWiUuk5AMMjvp8Hcv6O8thlehx+MLM/V4g/tio=",
      "url": "_framework/System.Console.1rvnj2uuzn.wasm"
    },
    {
      "hash": "sha256-2zsMNHh7r7VVu2prMhk7/X/OQu/GljLnLiH8XaMUW7o=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.fbsmb60tpv.wasm"
    },
    {
      "hash": "sha256-POBRVx22VpjjVrhkPk5A637pUdFjq7ILLJeluH0El+0=",
      "url": "_framework/System.IO.FileSystem.Watcher.suj9nniwax.wasm"
    },
    {
      "hash": "sha256-ry9tC37SIIrYHgYXnNy3IWtkNjhvU9Dx8hpnH28PG/8=",
      "url": "_framework/System.IO.Pipelines.579zrviz2a.wasm"
    },
    {
      "hash": "sha256-iTDMJDB56UdIof8bUyIFHuP1PRsvxTNFc0//xsP8kjw=",
      "url": "_framework/System.Linq.1ayotss27c.wasm"
    },
    {
      "hash": "sha256-Kskp72XKq4eVTngYXsQzY4eP1/sEsfBMbwoaULhIKw8=",
      "url": "_framework/System.Memory.y9jx703bdt.wasm"
    },
    {
      "hash": "sha256-PNsjj+Z1If7MBB0/UT30/MeHMjd+hfKX0YVufdZ1bb8=",
      "url": "_framework/System.Net.Http.Json.wthiag7kqp.wasm"
    },
    {
      "hash": "sha256-+RTY4dU+Xx30GgnXuGexVaVS7yA8ZBBvpcUANdGo+xw=",
      "url": "_framework/System.Net.Http.vaos9ua0ns.wasm"
    },
    {
      "hash": "sha256-jXaohvPeU9Q65oiUct9I1c+ErO4PjEH5qo3DT43F4ro=",
      "url": "_framework/System.Net.Primitives.hz94rc8ds9.wasm"
    },
    {
      "hash": "sha256-TrFC6vRtR9jX3baowPlnnPPJmpQSL4OSUxj5y/C/tEo=",
      "url": "_framework/System.Private.CoreLib.ayqh81oqhf.wasm"
    },
    {
      "hash": "sha256-ovERuqdSKkaK435ACu5GZx8yUQE4VWMMasl7DOLUp70=",
      "url": "_framework/System.Private.Uri.inhw91eri4.wasm"
    },
    {
      "hash": "sha256-atY8hb/rIHUbWtvrSeB+okS9Y/9HShtmBX/hBopJ6Y0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.e3rxrh7ufy.wasm"
    },
    {
      "hash": "sha256-fn/+eeNSyGQUdRWl8f6YNvEEVB1V8gWq0bFLc2e0Cgc=",
      "url": "_framework/System.Runtime.ucr485ybk2.wasm"
    },
    {
      "hash": "sha256-W1jC/mnsH6oLuqHy0KjjIWWKPD7NEEP1TGtZYqwKHvY=",
      "url": "_framework/System.Security.Cryptography.ju57v00z47.wasm"
    },
    {
      "hash": "sha256-ffnHY+D8q4nDXqeKQf+O2B2Ml0JIJXg0sK9NX7HuJMs=",
      "url": "_framework/System.Text.Encodings.Web.ftuq4piphg.wasm"
    },
    {
      "hash": "sha256-M65oGicdzVJ+occmiLCI0SphGBCUxuApaJkwy32kvcY=",
      "url": "_framework/System.Text.Json.z0dtz1y8qz.wasm"
    },
    {
      "hash": "sha256-rUYwHVllfQmSm7VtF7cc19lIos+iMKj/lq9zNPrkU6c=",
      "url": "_framework/System.Text.RegularExpressions.f1aur4qc1u.wasm"
    },
    {
      "hash": "sha256-dYqqojdFQ6rRM+2h2d7vEW38bl8hOhA+Ihm/kHTV1bM=",
      "url": "_framework/System.Threading.zaomlvk0ko.wasm"
    },
    {
      "hash": "sha256-keNOvlGwePvZRKiWl2DcYJhBfqSYYernf6TBnUwmQ2Y=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-C6VEWJvr8/4p8V9CoiDu1P5WjlEOa5J8TwcJ/G/8V14=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-r+0JJkNRopcjCdvu4kNlzuZR2a6pE+/WCMG/1eFdRCI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-eMk64pC3Q6fTsCfedkEPI0jxY2UHMwg0Kb8iog5byHk=",
      "url": "_framework/dotnet.native.sf5ot6v8sz.js"
    },
    {
      "hash": "sha256-AGcFXym3lbb/7cHPkdAJerV/k2nl2swXQZR0dLN2YUQ=",
      "url": "_framework/dotnet.native.wosz13dbnw.wasm"
    },
    {
      "hash": "sha256-1lGQC47gePi9fLGPDXRbA//I7x1RZ2FrSoAwS/Piloo=",
      "url": "_framework/dotnet.runtime.26xtx0erx2.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-xNhbS3M+UbbEtpBXwSPXq8WRyNRZ9GoGUdd936Mpf9s=",
      "url": "_framework/netstandard.wv8xs4pr36.wasm"
    },
    {
      "hash": "sha256-6RXhOZxq/ebNG5RWIbNevzam4HUqLRstJRUK6hcToxs=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-5uUU9eWNijPREscWDgBTLe0oMh/o0TiNMViHti6S428=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-9kPW/n5nn53j4WMRYAxe9c1rCY96Oogo/MKSVdKzPmI=",
      "url": "css/bootstrap-icons/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-ux3pibg5cPb05U3hzZdMXLpVtzWC2l4bIlptDt8ClIM=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff"
    },
    {
      "hash": "sha256-R2rfQrQDJQmPz6izarPnaRhrtPbOaiSXU+LhqcIr+Z4=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff2"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-oDfhP6vFAVEbRGVxIaypqe8AmCbJhX/zIJLInpYmV/A=",
      "url": "css/index.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-9kPW/n5nn53j4WMRYAxe9c1rCY96Oogo/MKSVdKzPmI=",
      "url": "fonts/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-1tc1ZEs9VWkgjKf0kBSsaJCwhHWCc7FBu7IJ9Js3baw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7B6kJ5JP+jYicVjO6H8NxrHpN3EQFf8RfBnjIr70ogA=",
      "url": "js/dropZone.js"
    },
    {
      "hash": "sha256-Pm2aUGfSH44QUZzlfj6/x2QXoTUApmL3DwCQcU5zFF4=",
      "url": "js/indexedDbService.js"
    },
    {
      "hash": "sha256-aUb3ORrlhqUdwsSSIni0w0V49CwHALJfij+8zkmkXNo=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
