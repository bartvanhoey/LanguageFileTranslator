self.assetsManifest = {
  "version": "RV3yQYkg",
  "assets": [
    {
      "hash": "sha256-QgBt7UfRR5GB3ZboiEunvxBwAM87mvaDJxfS4oDyhsE=",
      "url": "JsonTranslatorApp.styles.css"
    },
    {
      "hash": "sha256-K2Wvsx9NvmtkU4V07OCHCR0wmY6uNAnSuHp+KN2yAwc=",
      "url": "_framework/JetBrains.Annotations.75veoqxomf.wasm"
    },
    {
      "hash": "sha256-lvKIjhT3MzeoZQL1bi2XRUTQyrGP/8rgoQYMjCp5EFQ=",
      "url": "_framework/JsonTranslatorApp.e7mg9on3kb.wasm"
    },
    {
      "hash": "sha256-gzmhnihJhEFHMTPhuPsKNtCQ0kGmi7BsHvGEPetNfFY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r2qa7kydow.wasm"
    },
    {
      "hash": "sha256-g01RnE95orSyEDB8phBNU8C4+IYK4K10lVS6LLY3j0o=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.lujwi9v6ic.wasm"
    },
    {
      "hash": "sha256-32u/Td3GvkBhhxM7wtlyLk/sOKTuwr+8ECvVRWS2cvE=",
      "url": "_framework/Microsoft.AspNetCore.Components.f8vznv9s0u.wasm"
    },
    {
      "hash": "sha256-HJIuQE6pKDJFrRcY1jDZc24r/oCvDJcAkw4nDaAB8qI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.cksy1vh92g.wasm"
    },
    {
      "hash": "sha256-FxvhV0egQoUYZtlpOv/QILGYjo01keOT8w73DMQdKqE=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.31fs8yh8wp.wasm"
    },
    {
      "hash": "sha256-dDnUahx3kenxvQhydraohZXWz5En8WVKhE3qrPMyHR8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.s0rjvyn8xj.wasm"
    },
    {
      "hash": "sha256-Yip5M4RqUoGCQwfivtRll5/1N0KGJHCUqYUMsvekoFo=",
      "url": "_framework/Microsoft.Extensions.Configuration.a99zs4tvnc.wasm"
    },
    {
      "hash": "sha256-ZpoQHnoofRuZTHg/haeBbFGHcaNSMLmdj33xCsAkhho=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.uf2h3niqcd.wasm"
    },
    {
      "hash": "sha256-IUnxFZGhEYKTcdbelb5pRC0xc4eRkIJ+sGSX7AmGnvc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.n2o4gdkz70.wasm"
    },
    {
      "hash": "sha256-3vnozxlqCmq8jVVb9mwAQxudM0OnZZ6dlUnB4q3xW28=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.uxmwiizn8l.wasm"
    },
    {
      "hash": "sha256-lF/qDoYK2pkNFRqcguVDwWsO8mnG9tStsqEVKC16xvs=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.8f70m9ezd9.wasm"
    },
    {
      "hash": "sha256-8lc9RnbdFXTxsIs1W3mnoEgQQHphzwPnXnxl6D3xo4Q=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.6630cfrrwy.wasm"
    },
    {
      "hash": "sha256-FywfTjMX7kCnEXjXvRjC8NRMHYDX1NUVEkC5PLvpnnY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.hqrmax7z50.wasm"
    },
    {
      "hash": "sha256-Gggwh6f+Wd7VWKrnTSlZ2Pp+YqvY9qzpLuMlvJA0xCY=",
      "url": "_framework/Microsoft.Extensions.Logging.uayxka1r1j.wasm"
    },
    {
      "hash": "sha256-sUHBqClXdANp1LJV4yiu0KS+PFjsZvND4ol7yXAyY4U=",
      "url": "_framework/Microsoft.Extensions.Options.146r6pmryz.wasm"
    },
    {
      "hash": "sha256-LgXw3O13FGwOcrqBJ62adSuXya/XuIdi/mYVRR8IyB8=",
      "url": "_framework/Microsoft.Extensions.Primitives.meywjvcgzj.wasm"
    },
    {
      "hash": "sha256-l4822aWDv6TJPgb67s344sWo4iK3FwEXkLjpgYNYS0k=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.90ixfq4lhh.wasm"
    },
    {
      "hash": "sha256-5hGV8fXVIcdu88Yc8VwjjjlPve03aeK7JWJT9jpTyeY=",
      "url": "_framework/Microsoft.JSInterop.i1fnmsiyzg.wasm"
    },
    {
      "hash": "sha256-/O2IOIuG+a+6OmI6+oeBlFKHdq52RrhLJq1+qVcZn7w=",
      "url": "_framework/System.Collections.Concurrent.ob60u56uj2.wasm"
    },
    {
      "hash": "sha256-d/PV96ZYy5H1/tV/SaUUQ9P3YONiIi49DQ/bXZeD9f4=",
      "url": "_framework/System.Collections.Immutable.9cdk4e963w.wasm"
    },
    {
      "hash": "sha256-8qmf9agVLlJOfbyBUGEO2oHVuLPIu+jfjCtaEgmsXG8=",
      "url": "_framework/System.Collections.a6ln3zdrl1.wasm"
    },
    {
      "hash": "sha256-sC3/rhV0lry+D9pymYdYDpiIYTVlsufGh6+MiAaFQEE=",
      "url": "_framework/System.ComponentModel.Primitives.ctbm17xvex.wasm"
    },
    {
      "hash": "sha256-birhpt8jSv/U2qdhGfU4p4NXVfovePw2Ydscrr6pAIQ=",
      "url": "_framework/System.ComponentModel.ikbswb499r.wasm"
    },
    {
      "hash": "sha256-+PAa6S/EqYAHgvqge4CumUtyKmSZDhbubVHjvyZ/E1M=",
      "url": "_framework/System.Console.g69mtjz2qh.wasm"
    },
    {
      "hash": "sha256-b3n5dxEd+tMr/RJtqKl7DLXBozy0Mb038hZeojUG0ic=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.jv4vzvbfli.wasm"
    },
    {
      "hash": "sha256-RAWYgEiFlkfQQZqjMHbgQ5GVdOImxWEmGzU0FLUX3h4=",
      "url": "_framework/System.IO.FileSystem.Watcher.4irqp9315t.wasm"
    },
    {
      "hash": "sha256-fAz3TblymrCb/pQIvOgCct3momuizPTHWB2J/+6Ux1c=",
      "url": "_framework/System.IO.Pipelines.wtlwtstrfr.wasm"
    },
    {
      "hash": "sha256-44zh5o2RukeJy8o01ZfpsRoCKX4PAJJTOtPrbjNVI2U=",
      "url": "_framework/System.Linq.h3uf1ndg9p.wasm"
    },
    {
      "hash": "sha256-oTJXqCe9KxaiGGuGLls8FwZQ5Ujtj1QoZib+HYmh4Z0=",
      "url": "_framework/System.Memory.725vicqgao.wasm"
    },
    {
      "hash": "sha256-4q2o2WGnljRPUfDrPsprqxfELf90q/g9Qdg9RmpukMQ=",
      "url": "_framework/System.Net.Http.Json.ig90yjvk78.wasm"
    },
    {
      "hash": "sha256-C/PRH++tTi9zypN3MC2LjP0PRWL767/nvDb9ANWXirE=",
      "url": "_framework/System.Net.Http.rw74mjzz76.wasm"
    },
    {
      "hash": "sha256-lxfBS0jFlGFxMmOK4Q3JCiyq6winSiB0aE85Rnc3fo8=",
      "url": "_framework/System.Net.Primitives.jpw0iktit7.wasm"
    },
    {
      "hash": "sha256-FmKVEWP0HDIs681xSGdnmeWjMNSDWuhHbWAtSibWcMk=",
      "url": "_framework/System.Private.CoreLib.ab0qyzthws.wasm"
    },
    {
      "hash": "sha256-aZ09BVePWpn+rTWZMFYK0Nn6OnLdCm/7nmCQNsu8+Ag=",
      "url": "_framework/System.Private.Uri.bbgw0i4uce.wasm"
    },
    {
      "hash": "sha256-xxV3zUzfCbXTJ2ubQPlrZUW6WIaghnUk04n2VnKwLBo=",
      "url": "_framework/System.Runtime.5xll0quozi.wasm"
    },
    {
      "hash": "sha256-awsTmrrIsJQCrfl82Mjn6QsVMjU6CYPfkSAfZoEkQTc=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.7t9nyqzt69.wasm"
    },
    {
      "hash": "sha256-dAlTQTgdBOJ5Lw73xIZoWergcP8Xetfk1lyx943wY94=",
      "url": "_framework/System.Security.Cryptography.sav0zurinl.wasm"
    },
    {
      "hash": "sha256-XwvZL/UGxE+e47gOPh4EabKxv9YOIj6jvmkG5yniNiM=",
      "url": "_framework/System.Text.Encodings.Web.lbouqhqtd4.wasm"
    },
    {
      "hash": "sha256-UpLITaT3E+2x4bc74eD3hye4QEfE+V2l+vcERaEnEGM=",
      "url": "_framework/System.Text.Json.qlyyu7fhjb.wasm"
    },
    {
      "hash": "sha256-vuJAJ79JNzscm0ZSYdU//uy4gCU/YoGnVYiNij9nwCg=",
      "url": "_framework/System.Text.RegularExpressions.mya9jwxzzy.wasm"
    },
    {
      "hash": "sha256-H8KZ4vdZaFxiaM6XFo8QmJbNMX7yOMN9I2UQlJB1Ddo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-xt8RyUsprzUajnIi0I3fe6oJHxQ60AIkMBKyIK6CLNE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-ONpJkJu1uYz96ZP615rMF19wVzWwHXaWcLEhVlqose4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ofb3e66yO44iXeGpop3z7ZtJ2QTJzQqIIcZ8iAO3xQs=",
      "url": "_framework/dotnet.native.h8fabsjujg.wasm"
    },
    {
      "hash": "sha256-bYsObSgboPWIEBe4HlsdO7Xwtr2aQK80B3Aezrklu2Y=",
      "url": "_framework/dotnet.native.rekxzbo49u.js"
    },
    {
      "hash": "sha256-Nxi58ygfXerbT8jR1N/1rm08zEP+Doobp9HRXVfpS1M=",
      "url": "_framework/dotnet.runtime.h6izlfp54g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-LHKcCAzCtUvodO/5u4tcdyBMNBuF+ct+JTZkdt6++sg=",
      "url": "_framework/netstandard.k4ricmlhu7.wasm"
    },
    {
      "hash": "sha256-b+efmmXfQSt5ovNDa18uV05qNwxbK28NvdrfiDXvmeI=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-5uUU9eWNijPREscWDgBTLe0oMh/o0TiNMViHti6S428=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-9kPW/n5nn53j4WMRYAxe9c1rCY96Oogo/MKSVdKzPmI=",
      "url": "css/bootstrap-icons/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-ux3pibg5cPb05U3hzZdMXLpVtzWC2l4bIlptDt8ClIM=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff"
    },
    {
      "hash": "sha256-R2rfQrQDJQmPz6izarPnaRhrtPbOaiSXU+LhqcIr+Z4=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff2"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-oDfhP6vFAVEbRGVxIaypqe8AmCbJhX/zIJLInpYmV/A=",
      "url": "css/index.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-9kPW/n5nn53j4WMRYAxe9c1rCY96Oogo/MKSVdKzPmI=",
      "url": "fonts/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-+ogQ/+EpM72VqaW11aMiOHhmIolUIJxBPBxdKiGbMs4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7B6kJ5JP+jYicVjO6H8NxrHpN3EQFf8RfBnjIr70ogA=",
      "url": "js/dropZone.js"
    },
    {
      "hash": "sha256-aUb3ORrlhqUdwsSSIni0w0V49CwHALJfij+8zkmkXNo=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
