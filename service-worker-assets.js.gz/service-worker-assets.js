self.assetsManifest = {
  "version": "CoWBSOiQ",
  "assets": [
    {
      "hash": "sha256-Te1z7gjPiLsS8Eaqd7uYmQxyf5/74Yhra1pmHVLyVUc=",
      "url": "LanguageFileTranslatorApp.styles.css"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-K2Wvsx9NvmtkU4V07OCHCR0wmY6uNAnSuHp+KN2yAwc=",
      "url": "_framework/JetBrains.Annotations.75veoqxomf.wasm"
    },
    {
      "hash": "sha256-bv1fmKUgAMqESc/UUV0n/Rm/Q3HYPJwyUQqwG8fneFk=",
      "url": "_framework/LanguageFileTranslatorApp.i0cr56xal6.wasm"
    },
    {
      "hash": "sha256-B6ZdIoZFDfJPlhENwliwnXE+pJg65OFAmRq13Kfo2i4=",
      "url": "_framework/Microsoft.AspNetCore.Components.3l5jzg0jy9.wasm"
    },
    {
      "hash": "sha256-e6NYhsj8eyJ1xkOGNY+n8smq4qdDYzh6A1KGIaH57X4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jim68xox88.wasm"
    },
    {
      "hash": "sha256-wqN95Lh/pnVkqk+dI3ZqbE5P7IdTODTrkrYVdMm5ViI=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.upqayvcoqo.wasm"
    },
    {
      "hash": "sha256-tkqSXRzZPeNbxtJ+IaZQez5Sw1oYvnS1QEhL3d5WvMQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.68pc0kvab2.wasm"
    },
    {
      "hash": "sha256-P7JqI4xNIvLXRyszZZ+sgn49azkqo9B1U0UYy5OyYs4=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.9egjw13m6v.wasm"
    },
    {
      "hash": "sha256-3D9JIcKCrX/w6+4jFQ8q9N/67OPnjpLLNIEFN22xVSY=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.wp0mzg5a2w.wasm"
    },
    {
      "hash": "sha256-ykA0KZ0JrE4ZtKEg8fgvq/wsCuLKkZmwiVwgA3Ydt6c=",
      "url": "_framework/Microsoft.Extensions.Configuration.q0vfeqgy49.wasm"
    },
    {
      "hash": "sha256-22CpaX3eLYa7FVgM7NU/tco9Kz2NLDphUTm19IL0aFU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.pfv0oyi8se.wasm"
    },
    {
      "hash": "sha256-Fx8PCZC8Hf7hAImnq6oOpMXcz/p4nQ1AyyS8feAn3BU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.p0lak51igt.wasm"
    },
    {
      "hash": "sha256-XkiN+nwEj7Xe6j7gsH0Q4mHyupK6VJuvC7tRKSv2xBk=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.ik8tjtuunz.wasm"
    },
    {
      "hash": "sha256-uAZVYqVtDXOclUTIFSV8ibAkoaOOI/qUnJmhQXg8ppw=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.0mjc3e3c8g.wasm"
    },
    {
      "hash": "sha256-C2KktPfzpXATvVvmrPF83kGB5goRQ5qiW6huOCvg1Zg=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.r42d299edj.wasm"
    },
    {
      "hash": "sha256-36782JGnyrv2+Yshj8UhZB8OxEAoqHEOqB+KxNoNvnI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pu91p8h6ns.wasm"
    },
    {
      "hash": "sha256-YIuzDGZI83GlNESnYTyMbdqJLsSTloCYq5EUscVTcx4=",
      "url": "_framework/Microsoft.Extensions.Logging.knt2que0yn.wasm"
    },
    {
      "hash": "sha256-aXfYBfRdGv8Z1PBN/5+izXYTKgcXhu8iQhl647u56lw=",
      "url": "_framework/Microsoft.Extensions.Options.5lr3lli8bg.wasm"
    },
    {
      "hash": "sha256-AjsTRohUMSrR9ZfCOi79wRFoVpo/VcKSXP1ZOcQCFUU=",
      "url": "_framework/Microsoft.Extensions.Primitives.62v70z4iar.wasm"
    },
    {
      "hash": "sha256-7WtjYQMbGWwUn9g+l5J/EwBeIysEUj1NQmwD/6JVHi8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lqrqdcga09.wasm"
    },
    {
      "hash": "sha256-d+WqurQW/ue57ffE7+JqV04RMIdksBUD4YmHWaX9FYc=",
      "url": "_framework/Microsoft.JSInterop.lh96pnvlhf.wasm"
    },
    {
      "hash": "sha256-exQHdzhvy0633HD9HxVIWOnf51HZ7bxEzZNVFCBUbok=",
      "url": "_framework/System.Collections.1hmbx5fbni.wasm"
    },
    {
      "hash": "sha256-oPgOMgt3rN0EEjrQ3PMi31Gf0i9SB8buyg7MqRcy1Fo=",
      "url": "_framework/System.Collections.Concurrent.clml7v5scf.wasm"
    },
    {
      "hash": "sha256-LFeDGcz5KUj97tIN5cbDEiCazcjWdcmRdJ0EDIwshfE=",
      "url": "_framework/System.Collections.Immutable.k08dbxnf6x.wasm"
    },
    {
      "hash": "sha256-nXpkoiWO6DmS6vFKb5mBoUTIyVBcR/bPDf6qoB+OGPg=",
      "url": "_framework/System.ComponentModel.Primitives.jk0evfrvnk.wasm"
    },
    {
      "hash": "sha256-M+OiIE+Oyx/oKWxWqI26UnvKE3VJ2nAKycb2WJAt3wY=",
      "url": "_framework/System.ComponentModel.x3o7f6y5sp.wasm"
    },
    {
      "hash": "sha256-Z1z7KKNYEhO+PwQ8gzP3H1iksfKy2eOiafG+PSfm2wQ=",
      "url": "_framework/System.Console.94kjjha1eu.wasm"
    },
    {
      "hash": "sha256-aUZvOD0ah41FVXaUobL9sWBLG9bK2jfeYqgBfNUbw9Y=",
      "url": "_framework/System.IO.FileSystem.Watcher.9wi3sao117.wasm"
    },
    {
      "hash": "sha256-uF8ZFtMT3UcQ+rksd+djr/mp2VMOw/EUpnBxgOW0QlQ=",
      "url": "_framework/System.IO.Pipelines.o49ueulm8k.wasm"
    },
    {
      "hash": "sha256-D/uS85f70hZ6r/EmRpEUof7IApX5pap5RPPbeZeVt7Q=",
      "url": "_framework/System.Linq.jv2u1kyked.wasm"
    },
    {
      "hash": "sha256-MYyl4eKryY00Rbw537sJz3QvPpXOFwQMQd4SN3wmbXk=",
      "url": "_framework/System.Memory.hk1d73jf1p.wasm"
    },
    {
      "hash": "sha256-jEFAbL0lgM0awxjQYo17lcuqJwQskgTdY/9g/3ZeiGk=",
      "url": "_framework/System.Net.Http.wvdtixi319.wasm"
    },
    {
      "hash": "sha256-21cWyy6ao2n+qAbS+vB+89T7itFgP78Prg5NbWZsd38=",
      "url": "_framework/System.Net.Primitives.hphy61fras.wasm"
    },
    {
      "hash": "sha256-p9YPDqojR61aaXaXnTI5C/5Tr4fDng2SQuBsHoJS04c=",
      "url": "_framework/System.Private.CoreLib.vy4arx8wl4.wasm"
    },
    {
      "hash": "sha256-sfFYwnZVXfeTIKyrCK3jdkhp1AiCMmW6CFOmEwqnBXA=",
      "url": "_framework/System.Private.Uri.3fb672mez9.wasm"
    },
    {
      "hash": "sha256-18gMttpqgqHUxPxKyyIjficcW1PztE3y+emjkKxuCD4=",
      "url": "_framework/System.Runtime.592nod2111.wasm"
    },
    {
      "hash": "sha256-iyHAcUW3MeBhiBJYRDE3uHM1+K3ghZ+2EQK73u2xaM4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.vbi7xy05cc.wasm"
    },
    {
      "hash": "sha256-Jhvqades8xH/9lIfJ0mhhUdTH6H1XAspG5rlE/alGxc=",
      "url": "_framework/System.Security.Cryptography.i2sfhall1l.wasm"
    },
    {
      "hash": "sha256-44ybpXC/01lkhIS+rcQkH/u+e77NXred918NpPkhDK0=",
      "url": "_framework/System.Text.Encodings.Web.vharf8ldxb.wasm"
    },
    {
      "hash": "sha256-Z7yx6Tc2ctbGXFnhOQR1PJozS9WLz+ND+damjLRF1IU=",
      "url": "_framework/System.Text.Json.l5xns0a8f6.wasm"
    },
    {
      "hash": "sha256-osocHkbtHn4SWwaiTWsZSyXU0cxRv/gNNPN5Ux6WhMU=",
      "url": "_framework/System.Text.RegularExpressions.6jvkmeq68o.wasm"
    },
    {
      "hash": "sha256-nvJ3jBZyFxQ0Ah384UEBcclL0FkV5CRGAwbUlnWAR74=",
      "url": "_framework/System.Threading.e40w6tlim8.wasm"
    },
    {
      "hash": "sha256-Y9zlDypufbsHU9C4mXneMemV/AiCkD82Puj39lQW+Us=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-C6VEWJvr8/4p8V9CoiDu1P5WjlEOa5J8TwcJ/G/8V14=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-3+oINbl9anIpOQa27gJF6ci1He9ldU/ZrulG/oAmZBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-m5MyPS3j5tW9ODliiVvQz4dhDstoXqRfRa8RJpbATZU=",
      "url": "_framework/dotnet.native.1dxm2itite.wasm"
    },
    {
      "hash": "sha256-ZRtWJM79pph/Fb99iqGcEFLP2AZbaDrUXlhQdgux+lM=",
      "url": "_framework/dotnet.native.tu18g0hln1.js"
    },
    {
      "hash": "sha256-e/Ee0XzTQHVzg6pZms6FR5P6yEpTgaACDSAZCGD1PUo=",
      "url": "_framework/dotnet.runtime.ju77aherdp.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-V7iUKGT1ZmDiaEFUCkGRORCPv4SemVicd77sDYGkB5s=",
      "url": "_framework/netstandard.ldwztzpuqq.wasm"
    },
    {
      "hash": "sha256-6RXhOZxq/ebNG5RWIbNevzam4HUqLRstJRUK6hcToxs=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-9kPW/n5nn53j4WMRYAxe9c1rCY96Oogo/MKSVdKzPmI=",
      "url": "css/bootstrap-icons/bootstrap-icons.min.css"
    },
    {
      "hash": "sha256-ux3pibg5cPb05U3hzZdMXLpVtzWC2l4bIlptDt8ClIM=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff"
    },
    {
      "hash": "sha256-R2rfQrQDJQmPz6izarPnaRhrtPbOaiSXU+LhqcIr+Z4=",
      "url": "css/bootstrap-icons/fonts/bootstrap-icons.woff2"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-QYbBRuf7tgqXdThCNjTN50wnP0RARHz6hiy8o3EGtnk=",
      "url": "css/index.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-EQ2VPBUu6Cym8sZ1IFk05njnWQVQMNyJswNbDBUTm5I=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7B6kJ5JP+jYicVjO6H8NxrHpN3EQFf8RfBnjIr70ogA=",
      "url": "js/dropZone.js"
    },
    {
      "hash": "sha256-eIntnPhbk++YD3zke+B5raGA0sYchiAfMerK7RfAa+E=",
      "url": "js/indexedDbService.js"
    },
    {
      "hash": "sha256-Y7ThKB4tnf6U+y9YRKDNx3T7Xp/SiS+fSfuJ4O4bxqg=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
